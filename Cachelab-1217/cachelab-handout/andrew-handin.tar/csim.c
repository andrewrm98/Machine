#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>

#include <stdio.h>

typedef unsigned long address;

/* Lines are part of sets
*/
struct Line
{
	int valid;
	address tag;
	int age;
};

/* Sets are parts of a Cache
*/
struct Set
{
	struct Line* lines;
};

/* The full Cache
*/
struct Cache
{
	struct Set* sets;
};

typedef struct Line Line;
typedef struct Set Set;
typedef struct Cache Cache;

/* Initializer for the cache
*/
Cache initCache (long numLines, long numSets)
{
	// Necessary local variables, edit cache and return it
	Cache cache;
	Set set;
	Line line;
	line.valid = 0;
	line.tag = 0;
	line.age = 0;
	
	cache.sets = (Set*) malloc (sizeof(Set) * numSets); // dynamically allocate memory to the cache

	/* Dynamically allocate memory for each Set
	*/
	for(int i=0; i<numSets; i++)
	{
		set.lines = (Line*) malloc (sizeof(Line) * numLines); // dynamically allocate memory to the Lines
		
		/* set all lines to default values
		*/
		for(int j=0; j<numLines; j++)
		{
			set.lines[j] = line; // fill the set with default lines
		}

		cache.sets[i] = set; // fill the cache with default sets
	}

	/* Prints out the cache for referencial purposes
	*/
	for(int i = 0; i<numSets; i++)
	{
		for(int j=0; j<numLines; j++)
		{
			printf("valid: %d, age: %d\n", cache.sets[i].lines[j].valid, cache.sets[i].lines[j].age);
		}
	}
	return cache;
}


int main()
{
	initCache(3, 3);
    printSummary(0, 0, 0);
    return 0;
}